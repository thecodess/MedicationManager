package com.apps.thecodess.medicationmanger.utils;

import android.os.Build;

import android.os.Bundle;
import android.view.Window;

import androidx.appcompat.app.AppCompatActivity;

import com.developer.nennenwodo.medmanager.R;

public class BaseActivity extends AppCompatActivity {

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT <= 22) {
            Window window = getWindow();
            window.setStatusBarColor(getResources().getColor(R.color.dark_middle_gray));
        }
    }
}
